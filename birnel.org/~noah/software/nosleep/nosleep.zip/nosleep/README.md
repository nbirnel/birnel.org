nosleep, 
a tiny utility to prevent Windows operating systems from sleeping or locking - 
whatever your system administrator may say.

For security reasons, 
I don't recommend using this program under most conditions.
If you don't know when it would be safe -
it wouldn't be safe.

You'll need (AutoHotkey)[http://www.autohotkey.com/] to compile this. 

There is a 
[home page](http://www.birnel.org/~noah/software/nosleep/index.html),
where you can get the executable.
