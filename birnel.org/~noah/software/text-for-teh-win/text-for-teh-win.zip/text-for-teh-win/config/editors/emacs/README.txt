emacs-specific configurations for class, title, and process
