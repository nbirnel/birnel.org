gvim-specific configurations for class, title, and process
