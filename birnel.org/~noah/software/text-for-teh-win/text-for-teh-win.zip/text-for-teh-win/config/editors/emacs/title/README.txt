emacs title configs
