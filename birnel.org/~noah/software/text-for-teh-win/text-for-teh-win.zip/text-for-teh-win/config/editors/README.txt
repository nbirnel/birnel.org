Put directories here named after the edit_short variable specified in
%USERPROFILE%\.config\text-for-teh-win\config.ini
