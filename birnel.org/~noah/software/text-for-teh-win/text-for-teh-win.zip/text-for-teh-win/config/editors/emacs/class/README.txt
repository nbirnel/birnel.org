emacs class configs
