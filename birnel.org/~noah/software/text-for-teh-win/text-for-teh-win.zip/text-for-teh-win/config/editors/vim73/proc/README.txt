gvim process configs
