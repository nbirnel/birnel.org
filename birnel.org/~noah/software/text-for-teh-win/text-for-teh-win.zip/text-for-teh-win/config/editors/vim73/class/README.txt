gvim class configs
