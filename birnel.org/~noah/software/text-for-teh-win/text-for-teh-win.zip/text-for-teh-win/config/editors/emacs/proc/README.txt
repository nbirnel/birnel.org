emacs process configs
