This directory structure goes at %USERPROFILE%\.config\text-for-teh-win
